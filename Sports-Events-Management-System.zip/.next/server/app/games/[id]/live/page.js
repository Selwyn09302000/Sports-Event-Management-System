(()=>{var a={};a.id=8075,a.ids=[8075],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},938:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,3991,23)),Promise.resolve().then(c.bind(c,25671))},2050:(a,b,c)=>{"use strict";c.d(b,{O:()=>g});var d=c(29199),e=c(12971),f=c(10326);function g(a){let b=(0,f.Sq)({gameId:a.gameId,organizationId:a.organizationId}),c=b.game,g=b.boxScore.teams.find(a=>a.teamId===c.homeTeamId),h=b.boxScore.teams.find(a=>a.teamId===c.awayTeamId),i=(0,e.xH)(`SELECT MAX(o.remote_confirmed_at) AS at
         FROM sync_operations o JOIN game_events e ON e.id = o.entity_id
        WHERE e.game_id = ? AND o.status = 'synchronized'`,[c.id])?.at??null,j=((0,e.xH)("SELECT COUNT(*) AS n FROM game_results WHERE game_id = ? AND status = 'approved'",[c.id])?.n??0)>0;return{gameId:c.id,status:c.status,statusLabel:d.Sm[c.status]??c.status,period:b.clock.period,periodCount:c.periodCount,clock:{remainingMs:b.clock.remainingMs,running:b.clock.running,expired:b.clock.expired,anchorAt:b.clock.anchorAt,serverNow:b.clock.serverNow},home:{teamId:c.homeTeamId,name:c.homeTeamName,shortName:c.homeShort,color:c.homeColor,score:c.homeScore,teamFouls:g?.fouls??0,timeoutsUsed:g?.timeoutsUsed??0},away:{teamId:c.awayTeamId,name:c.awayTeamName,shortName:c.awayShort,color:c.awayColor,score:c.awayScore,teamFouls:h?.fouls??0,timeoutsUsed:h?.timeoutsUsed??0},tournamentName:b.tournament.name,tournamentFormat:b.format,divisionName:c.divisionName,venueName:c.venueName,scheduledAt:c.scheduledAt,lastEventSeq:c.lastEventSeq,updatedAt:c.updatedAt,lastSyncedAt:i,pendingSyncEvents:b.pendingSyncEvents,syncState:0===b.pendingSyncEvents?"synchronized":i?"pending":"local_only",hasApprovedResult:j}}},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12971:(a,b,c)=>{"use strict";c.d(b,{Q7:()=>f,eF:()=>h,qF:()=>i,xH:()=>g});var d=c(79032);function e(a){return void 0===a?null:"boolean"==typeof a?+!!a:a}function f(a,b=[],c=(0,d.Lf)()){return c.prepare(a).all(...b.map(e))}function g(a,b=[],c=(0,d.Lf)()){return c.prepare(a).get(...b.map(e))}function h(a,b=[],c=(0,d.Lf)()){return{changes:Number(c.prepare(a).run(...b.map(e)).changes)}}function i(a,b){if(!a)return b;try{return JSON.parse(a)}catch{return b}}},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},25671:(a,b,c)=>{"use strict";c.d(b,{PublicLive:()=>i});var d=c(21124),e=c(3991),f=c.n(e),g=c(38301),h=c(55241);function i({gameId:a,initial:b}){let[c,e]=(0,g.useState)(b),[i,j]=(0,g.useState)(!1),[k,l]=(0,g.useState)(()=>Date.now()),m=(0,g.useRef)(0);(0,g.useRef)(Date.now());let n=(0,g.useMemo)(()=>{if(!c.clock.running)return c.clock.remainingMs;let a=Date.parse(c.clock.anchorAt);return Math.max(0,c.clock.remainingMs-(k+m.current-a))},[k,c.clock]);return(0,d.jsxs)("div",{className:"rounded-2xl bg-slate-900 p-6 text-white shadow-lg",children:[(0,d.jsxs)("div",{className:"flex flex-wrap items-center justify-between gap-2 text-xs",children:[(0,d.jsx)("p",{className:"font-bold uppercase tracking-[0.25em] text-orange-400",children:c.statusLabel}),(0,d.jsxs)("p",{className:"text-slate-400",children:[c.clock.running?"Clock running":"Clock stopped"," \xb7 Period ",c.period,"/",c.periodCount]})]}),(0,d.jsxs)("div",{className:"mt-5 grid grid-cols-[1fr_auto_1fr] items-center gap-3",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("p",{className:"truncate text-sm font-semibold uppercase tracking-wide text-slate-300",children:c.home.name}),(0,d.jsx)("p",{className:"tabular font-mono text-6xl font-black",children:c.home.score}),(0,d.jsxs)("p",{className:"text-xs text-slate-400",children:["Team fouls ",c.home.teamFouls]})]}),(0,d.jsxs)("div",{className:"text-center",children:[(0,d.jsx)("p",{className:"tabular font-mono text-4xl font-black text-amber-300",children:(0,h.ei)(n)}),(0,d.jsxs)("p",{className:"text-[11px] uppercase tracking-widest text-slate-400",children:["Period ",c.period]})]}),(0,d.jsxs)("div",{className:"text-right",children:[(0,d.jsx)("p",{className:"truncate text-sm font-semibold uppercase tracking-wide text-slate-300",children:c.away.name}),(0,d.jsx)("p",{className:"tabular font-mono text-6xl font-black",children:c.away.score}),(0,d.jsxs)("p",{className:"text-xs text-slate-400",children:["Team fouls ",c.away.teamFouls]})]})]}),(0,d.jsxs)("div",{className:"mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-3 text-xs text-slate-400",children:[(0,d.jsxs)("span",{children:[i?"Live connection":"Reconnecting…",c.pendingSyncEvents>0?` \xb7 ${c.pendingSyncEvents} change(s) not yet in the cloud`:c.lastSyncedAt?` \xb7 cloud updated ${new Date(c.lastSyncedAt).toLocaleTimeString()}`:" \xb7 cloud sync not configured"]}),(0,d.jsx)(f(),{className:"font-semibold text-white hover:underline",href:`/games/${a}/box-score`,children:"Box score →"})]}),c.pendingSyncEvents>0?(0,d.jsx)("p",{className:"mt-3 rounded-lg bg-amber-500/15 px-3 py-2 text-[11px] text-amber-200",children:"The cloud does not have the latest score yet. This figure comes from the venue's official local record and will publish once connectivity returns."}):null]})}},26713:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/is-bot")},26787:(a,b,c)=>{"use strict";c.d(b,{Z:()=>e,o:()=>d});let d=[{version:"0001_init",sql:`CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  contact_email TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  roles TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TEXT NOT NULL,
  UNIQUE (organization_id, user_id)
);
CREATE INDEX idx_members_user ON organization_members(user_id);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  active_organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE sports (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE tournaments (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  starts_on TEXT,
  ends_on TEXT,
  sport_key TEXT NOT NULL REFERENCES sports(key),
  format TEXT NOT NULL DEFAULT 'round_robin',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  ruleset_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT,
  roster_locked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tournaments_org ON tournaments(organization_id, status);

CREATE TABLE divisions (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age_group TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, name)
);

CREATE TABLE teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  short_name TEXT,
  color TEXT,
  logo_url TEXT,
  contact_name TEXT,
  contact_phone TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_teams_org ON teams(organization_id);

CREATE TABLE tournament_teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  seed INTEGER,
  status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','confirmed','withdrawn')),
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id)
);
CREATE INDEX idx_tournament_teams_div ON tournament_teams(division_id);

CREATE TABLE players (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  birth_date TEXT,
  guardian_name TEXT,
  contact_phone TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_players_org ON players(organization_id);

CREATE TABLE roster_entries (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','inactive')),
  eligible INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id, jersey_number),
  UNIQUE (tournament_id, player_id)
);
CREATE INDEX idx_roster_team ON roster_entries(team_id);

CREATE TABLE venues (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  address TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE games (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  home_team_id TEXT NOT NULL REFERENCES teams(id),
  away_team_id TEXT NOT NULL REFERENCES teams(id),
  venue_id TEXT REFERENCES venues(id) ON DELETE SET NULL,
  scheduled_at TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  stage TEXT NOT NULL DEFAULT 'group',
  round_number INTEGER NOT NULL DEFAULT 1,
  bracket_slot INTEGER,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  current_period INTEGER NOT NULL DEFAULT 1,
  period_count INTEGER NOT NULL DEFAULT 4,
  period_seconds INTEGER NOT NULL DEFAULT 600,
  version INTEGER NOT NULL DEFAULT 1,
  last_event_seq INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (home_team_id <> away_team_id)
);
CREATE INDEX idx_games_tournament ON games(tournament_id, scheduled_at);
CREATE INDEX idx_games_org ON games(organization_id, status);

CREATE TABLE game_periods (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  period_number INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  started_at TEXT,
  ended_at TEXT,
  PRIMARY KEY (game_id, period_number)
);

CREATE TABLE game_clock_states (
  game_id TEXT PRIMARY KEY REFERENCES games(id) ON DELETE CASCADE,
  period INTEGER NOT NULL,
  remaining_ms INTEGER NOT NULL,
  running INTEGER NOT NULL DEFAULT 0,
  anchor_at TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

CREATE TABLE game_events (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  team_id TEXT,
  player_id TEXT,
  event_type TEXT NOT NULL,
  period INTEGER NOT NULL,
  clock_seconds_remaining INTEGER NOT NULL DEFAULT 0,
  occurred_at TEXT NOT NULL,
  recorded_by TEXT NOT NULL,
  recorded_by_name TEXT,
  device_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  schema_version INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  client_action_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synchronized','conflicted','rejected','local_only')),
  voided_at TEXT,
  voided_by TEXT,
  void_reason TEXT,
  corrects_event_id TEXT,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX idx_game_events_client_action ON game_events(game_id, client_action_id) WHERE client_action_id IS NOT NULL;
CREATE INDEX idx_game_events_game_seq ON game_events(game_id, seq);
CREATE INDEX idx_game_events_sync ON game_events(organization_id, sync_status);

CREATE TABLE player_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fgm2 INTEGER NOT NULL DEFAULT 0,
  fga2 INTEGER NOT NULL DEFAULT 0,
  fgm3 INTEGER NOT NULL DEFAULT 0,
  fga3 INTEGER NOT NULL DEFAULT 0,
  ftm INTEGER NOT NULL DEFAULT 0,
  fta INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  offensive_rebounds INTEGER NOT NULL DEFAULT 0,
  defensive_rebounds INTEGER NOT NULL DEFAULT 0,
  assists INTEGER NOT NULL DEFAULT 0,
  steals INTEGER NOT NULL DEFAULT 0,
  blocks INTEGER NOT NULL DEFAULT 0,
  turnovers INTEGER NOT NULL DEFAULT 0,
  substitutions INTEGER NOT NULL DEFAULT 0,
  seconds_played INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, player_id)
);

CREATE TABLE team_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  timeouts_used INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, team_id)
);

CREATE TABLE game_results (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  home_score INTEGER NOT NULL,
  away_score INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('submitted','approved','rejected','superseded')),
  submitted_by TEXT NOT NULL,
  submitted_at TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  rejection_reason TEXT,
  corrected_from_id TEXT,
  final_event_seq INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_results_game ON game_results(game_id, created_at);

CREATE TABLE tournament_rounds (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number)
);

CREATE TABLE bracket_advancements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  source_game_id TEXT,
  winner_team_id TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number, slot)
);

CREATE TABLE announcements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT REFERENCES tournaments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  published_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  device_key TEXT NOT NULL UNIQUE,
  authorized INTEGER NOT NULL DEFAULT 1,
  last_seen_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE sync_operations (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation TEXT NOT NULL DEFAULT 'upsert',
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','pushed','synchronized','conflicted','rejected')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  remote_confirmed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_sync_status ON sync_operations(status, created_at);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_user_id TEXT,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_org ON audit_logs(organization_id, created_at);
`}],e=d[d.length-1].version},28354:a=>{"use strict";a.exports=require("util")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},32469:(a,b,c)=>{"use strict";c.d(b,{PublicLive:()=>d});let d=(0,c(97954).registerClientReference)(function(){throw Error("Attempted to call PublicLive() from the server but PublicLive is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\ACERNITRO2026\\Desktop\\Sports-Events-Management-System\\src\\components\\public-live.tsx","PublicLive")},33873:a=>{"use strict";a.exports=require("path")},41025:a=>{"use strict";a.exports=require("next/dist/server/app-render/dynamic-access-async-storage.external.js")},54760:(a,b,c)=>{"use strict";c.r(b),c.d(b,{GlobalError:()=>F.a,__next_app__:()=>L,handler:()=>N,pages:()=>K,routeModule:()=>M,tree:()=>J});var d=c(34679),e=c(49754),f=c(9117),g=c(46595),h=c(32324),i=c(39326),j=c(38928),k=c(20175),l=c(12),m=c(54290),n=c(12696),o=c(52574),p=c(82802),q=c(77533),r=c(45229),s=c(32822),t=c(261),u=c(26453),v=c(52474),w=c(26713),x=c(51356),y=c(62685),z=c(36225),A=c(63446),B=c(2762),C=c(45742),D=c(86439),E=c(81170),F=c.n(E),G=c(62506),H=c(91203),I={};for(let a in G)0>["default","tree","pages","GlobalError","__next_app__","routeModule","handler"].indexOf(a)&&(I[a]=()=>G[a]);c.d(b,I);let J={children:["",{children:["games",{children:["[id]",{children:["live",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(c.bind(c,66570)),"C:\\Users\\ACERNITRO2026\\Desktop\\Sports-Events-Management-System\\src\\app\\games\\[id]\\live\\page.tsx"]}]},{}]},{}]},{}]},{layout:[()=>Promise.resolve().then(c.bind(c,51472)),"C:\\Users\\ACERNITRO2026\\Desktop\\Sports-Events-Management-System\\src\\app\\layout.tsx"],"global-error":[()=>Promise.resolve().then(c.t.bind(c,81170,23)),"next/dist/client/components/builtin/global-error.js"],"not-found":[()=>Promise.resolve().then(c.t.bind(c,87028,23)),"next/dist/client/components/builtin/not-found.js"],forbidden:[()=>Promise.resolve().then(c.t.bind(c,90461,23)),"next/dist/client/components/builtin/forbidden.js"],unauthorized:[()=>Promise.resolve().then(c.t.bind(c,32768,23)),"next/dist/client/components/builtin/unauthorized.js"]}]}.children,K=["C:\\Users\\ACERNITRO2026\\Desktop\\Sports-Events-Management-System\\src\\app\\games\\[id]\\live\\page.tsx"],L={require:c,loadChunk:()=>Promise.resolve()},M=new e.AppPageRouteModule({definition:{kind:f.RouteKind.APP_PAGE,page:"/games/[id]/live/page",pathname:"/games/[id]/live",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:J},distDir:".next",relativeProjectDir:""});async function N(a,b,e){var E;let I="/games/[id]/live/page";"/index"===I&&(I="/");let O=(0,i.getRequestMeta)(a,"postponed"),P=(0,i.getRequestMeta)(a,"minimalMode"),Q=await M.prepare(a,b,{srcPage:I,multiZoneDraftMode:!1});if(!Q)return b.statusCode=400,b.end("Bad Request"),null==e.waitUntil||e.waitUntil.call(e,Promise.resolve()),null;let{buildId:R,query:S,params:T,parsedUrl:U,pageIsDynamic:V,buildManifest:W,nextFontManifest:X,reactLoadableManifest:Y,serverActionsManifest:Z,clientReferenceManifest:$,subresourceIntegrityManifest:_,prerenderManifest:aa,isDraftMode:ab,resolvedPathname:ac,revalidateOnlyGenerated:ad,routerServerContext:ae,nextConfig:af,interceptionRoutePatterns:ag}=Q,ah=U.pathname||"/",ai=(0,t.normalizeAppPath)(I),{isOnDemandRevalidate:aj}=Q,ak=M.match(ah,aa),al=!!aa.routes[ac]&&(M.isDev||(0,d.isRouteCacheOwner)(ac,M.cacheOwner,aa.routes[ac])),am=!!(ak||al||aa.routes[ai]),an=a.headers["user-agent"]||"",ao=(0,w.getBotType)(an),ap=(0,r.isHtmlBotRequest)(a),aq=(0,i.getRequestMeta)(a,"isPrefetchRSCRequest")??"1"===a.headers[v.NEXT_ROUTER_PREFETCH_HEADER],ar=(0,i.getRequestMeta)(a,"isRSCRequest")??(0,o.f)(a.headers[v.RSC_HEADER]),as=(0,u.getIsPossibleServerAction)(a),at=(0,n.checkIsAppPPREnabled)(af.experimental.ppr)&&(null==(E=aa.routes[ai]??aa.dynamicRoutes[ai])?void 0:E.renderingMode)==="PARTIALLY_STATIC",au=!1,av=!1,aw=at?O:void 0,ax=at&&ar&&!aq,ay=(0,i.getRequestMeta)(a,"segmentPrefetchRSCRequest"),az=!an||(0,r.shouldServeStreamingMetadata)(an,af.htmlLimitedBots);ap&&at&&(am=!1,az=!1);let aA=!0===M.isDev||!am||"string"==typeof O||ax,aB=ap&&at,aC=null;ab||!am||aA||as||aw||ax||(aC=ac);let aD=aC;!aD&&M.isDev&&(aD=ac),M.isDev||ab||!am||!ar||ax||(0,l.d)(a.headers);let aE={...G,tree:J,pages:K,GlobalError:F(),handler:N,routeModule:M,__next_app__:L};Z&&$&&(0,q.setReferenceManifestsSingleton)({page:I,clientReferenceManifest:$,serverActionsManifest:Z,serverModuleMap:(0,s.createServerModuleMap)({serverActionsManifest:Z})});let aF=a.method||"GET",aG=(0,h.getTracer)(),aH=aG.getActiveScopeSpan();try{let d=M.getVaryHeader(ac,ag);b.setHeader("Vary",d);let g=async(c,d)=>{let e=new m.NodeNextRequest(a),f=new m.NodeNextResponse(b);return M.render(e,f,d).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=aG.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==j.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${aF} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${aF} ${a.url}`)})},l=async({span:d,postponed:f,fallbackRouteParams:h})=>{let j={query:S,params:T,page:ai,sharedContext:{buildId:R},serverComponentsHmrCache:(0,i.getRequestMeta)(a,"serverComponentsHmrCache"),fallbackRouteParams:h,renderOpts:{App:()=>null,Document:()=>null,pageConfig:{},ComponentMod:aE,Component:(0,k.T)(aE),params:T,routeModule:M,page:I,postponed:f,shouldWaitOnAllReady:aB,serveStreamingMetadata:az,supportsDynamicResponse:"string"==typeof f||aA,buildManifest:W,nextFontManifest:X,reactLoadableManifest:Y,subresourceIntegrityManifest:_,serverActionsManifest:Z,clientReferenceManifest:$,setIsrStatus:null==ae?void 0:ae.setIsrStatus,dir:c(33873).join(process.cwd(),M.relativeProjectDir),isDraftMode:ab,isRevalidate:am&&!f&&!ax,botType:ao,isOnDemandRevalidate:aj,isPossibleServerAction:as,assetPrefix:af.assetPrefix,nextConfigOutput:af.output,crossOrigin:af.crossOrigin,trailingSlash:af.trailingSlash,previewProps:aa.preview,deploymentId:af.deploymentId,enableTainting:af.experimental.taint,htmlLimitedBots:af.htmlLimitedBots,devtoolSegmentExplorer:af.experimental.devtoolSegmentExplorer,reactMaxHeadersLength:af.reactMaxHeadersLength,multiZoneDraftMode:!1,incrementalCache:(0,i.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:af.experimental.cacheLife,basePath:af.basePath,serverActions:af.experimental.serverActions,...au?{nextExport:!0,supportsDynamicResponse:!1,isStaticGeneration:!0,isRevalidate:!0,isDebugDynamicAccesses:au}:{},experimental:{isRoutePPREnabled:at,expireTime:af.expireTime,staleTimes:af.experimental.staleTimes,cacheComponents:!!af.experimental.cacheComponents,clientSegmentCache:!!af.experimental.clientSegmentCache,clientParamParsing:!!af.experimental.clientParamParsing,dynamicOnHover:!!af.experimental.dynamicOnHover,inlineCss:!!af.experimental.inlineCss,authInterrupts:!!af.experimental.authInterrupts,clientTraceMetadata:af.experimental.clientTraceMetadata||[]},waitUntil:e.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:()=>{},onInstrumentationRequestError:(b,c,d)=>M.onRequestError(a,b,d,ae),err:(0,i.getRequestMeta)(a,"invokeError"),dev:M.isDev}},l=await g(d,j),{metadata:m}=l,{cacheControl:n,headers:o={},fetchTags:p}=m;if(p&&(o[A.NEXT_CACHE_TAGS_HEADER]=p),a.fetchMetrics=m.fetchMetrics,am&&(null==n?void 0:n.revalidate)===0&&!M.isDev&&!at){let a=m.staticBailoutInfo,b=Object.defineProperty(Error(`Page changed from static to dynamic at runtime ${ac}${(null==a?void 0:a.description)?`, reason: ${a.description}`:""}
see more here https://nextjs.org/docs/messages/app-static-to-dynamic-error`),"__NEXT_ERROR_CODE",{value:"E132",enumerable:!1,configurable:!0});if(null==a?void 0:a.stack){let c=a.stack;b.stack=b.message+c.substring(c.indexOf("\n"))}throw b}return{value:{kind:x.CachedRouteKind.APP_PAGE,html:l,headers:o,rscData:m.flightData,postponed:m.postponed,status:m.statusCode,segmentData:m.segmentData},cacheControl:n}},n=async({hasResolved:c,previousCacheEntry:d,isRevalidating:g,span:h})=>{let j,k=!1===M.isDev,m=c||b.writableEnded;if(aj&&ad&&!d&&!P)return(null==ae?void 0:ae.render404)?await ae.render404(a,b):(b.statusCode=404,b.end("This page could not be found")),null;if(ak&&(j=(0,y.parseFallbackField)(ak.fallback)),j===y.FallbackMode.PRERENDER&&(0,w.isBot)(an)&&(!at||ap)&&(j=y.FallbackMode.BLOCKING_STATIC_RENDER),(null==d?void 0:d.isStale)===-1&&(aj=!0),aj&&(j!==y.FallbackMode.NOT_FOUND||d)&&(j=y.FallbackMode.BLOCKING_STATIC_RENDER),!P&&j!==y.FallbackMode.BLOCKING_STATIC_RENDER&&aD&&!m&&!ab&&V&&(k||!al)){let b;if((k||ak)&&j===y.FallbackMode.NOT_FOUND)throw new D.NoFallbackError;if(at&&!ar){let c="string"==typeof(null==ak?void 0:ak.fallback)?ak.fallback:k?ai:null;if(b=await M.handleResponse({cacheKey:c,req:a,nextConfig:af,routeKind:f.RouteKind.APP_PAGE,isFallback:!0,prerenderManifest:aa,isRoutePPREnabled:at,responseGenerator:async()=>l({span:h,postponed:void 0,fallbackRouteParams:k||av?(0,p.u)(ai):null}),waitUntil:e.waitUntil}),null===b)return null;if(b)return delete b.cacheControl,b}}let n=aj||g||!aw?void 0:aw;if(au&&void 0!==n)return{cacheControl:{revalidate:1,expire:void 0},value:{kind:x.CachedRouteKind.PAGES,html:z.default.EMPTY,pageData:{},headers:void 0,status:void 0}};let o=V&&at&&((0,i.getRequestMeta)(a,"renderFallbackShell")||av)?(0,p.u)(ah):null;return l({span:h,postponed:n,fallbackRouteParams:o})},o=async c=>{var d,g,h,j,k;let m,o=await M.handleResponse({cacheKey:aC,responseGenerator:a=>n({span:c,...a}),routeKind:f.RouteKind.APP_PAGE,isOnDemandRevalidate:aj,isRoutePPREnabled:at,req:a,nextConfig:af,prerenderManifest:aa,waitUntil:e.waitUntil});if(ab&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate"),M.isDev&&b.setHeader("Cache-Control","no-store, must-revalidate"),!o){if(aC)throw Object.defineProperty(Error("invariant: cache entry required but not generated"),"__NEXT_ERROR_CODE",{value:"E62",enumerable:!1,configurable:!0});return null}if((null==(d=o.value)?void 0:d.kind)!==x.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant app-page handler received invalid cache entry ${null==(h=o.value)?void 0:h.kind}`),"__NEXT_ERROR_CODE",{value:"E707",enumerable:!1,configurable:!0});let p="string"==typeof o.value.postponed;am&&!ax&&(!p||aq)&&(P||b.setHeader("x-nextjs-cache",aj?"REVALIDATED":o.isMiss?"MISS":o.isStale?"STALE":"HIT"),b.setHeader(v.NEXT_IS_PRERENDER_HEADER,"1"));let{value:q}=o;if(aw)m={revalidate:0,expire:void 0};else if(P&&ar&&!aq&&at)m={revalidate:0,expire:void 0};else if(!M.isDev)if(ab)m={revalidate:0,expire:void 0};else if(am){if(o.cacheControl)if("number"==typeof o.cacheControl.revalidate){if(o.cacheControl.revalidate<1)throw Object.defineProperty(Error(`Invalid revalidate configuration provided: ${o.cacheControl.revalidate} < 1`),"__NEXT_ERROR_CODE",{value:"E22",enumerable:!1,configurable:!0});m={revalidate:o.cacheControl.revalidate,expire:(null==(j=o.cacheControl)?void 0:j.expire)??af.expireTime}}else m={revalidate:A.CACHE_ONE_YEAR,expire:void 0}}else b.getHeader("Cache-Control")||(m={revalidate:0,expire:void 0});if(o.cacheControl=m,"string"==typeof ay&&(null==q?void 0:q.kind)===x.CachedRouteKind.APP_PAGE&&q.segmentData){b.setHeader(v.NEXT_DID_POSTPONE_HEADER,"2");let c=null==(k=q.headers)?void 0:k[A.NEXT_CACHE_TAGS_HEADER];P&&am&&c&&"string"==typeof c&&b.setHeader(A.NEXT_CACHE_TAGS_HEADER,c);let d=q.segmentData.get(ay);return void 0!==d?(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:z.default.fromStatic(d,v.RSC_CONTENT_TYPE_HEADER),cacheControl:o.cacheControl}):(b.statusCode=204,(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:z.default.EMPTY,cacheControl:o.cacheControl}))}let r=(0,i.getRequestMeta)(a,"onCacheEntry");if(r&&await r({...o,value:{...o.value,kind:"PAGE"}},{url:(0,i.getRequestMeta)(a,"initURL")}))return null;if(p&&aw)throw Object.defineProperty(Error("Invariant: postponed state should not be present on a resume request"),"__NEXT_ERROR_CODE",{value:"E396",enumerable:!1,configurable:!0});if(q.headers){let a={...q.headers};for(let[c,d]of(P&&am||delete a[A.NEXT_CACHE_TAGS_HEADER],Object.entries(a)))if(void 0!==d)if(Array.isArray(d))for(let a of d)b.appendHeader(c,a);else"number"==typeof d&&(d=d.toString()),b.appendHeader(c,d)}let s=null==(g=q.headers)?void 0:g[A.NEXT_CACHE_TAGS_HEADER];if(P&&am&&s&&"string"==typeof s&&b.setHeader(A.NEXT_CACHE_TAGS_HEADER,s),!q.status||ar&&at||(b.statusCode=q.status),!P&&q.status&&H.RedirectStatusCode[q.status]&&ar&&(b.statusCode=200),p&&b.setHeader(v.NEXT_DID_POSTPONE_HEADER,"1"),ar&&!ab){if(void 0===q.rscData){if(q.postponed)throw Object.defineProperty(Error("Invariant: Expected postponed to be undefined"),"__NEXT_ERROR_CODE",{value:"E372",enumerable:!1,configurable:!0});return(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:q.html,cacheControl:ax?{revalidate:0,expire:void 0}:o.cacheControl})}return(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:z.default.fromStatic(q.rscData,v.RSC_CONTENT_TYPE_HEADER),cacheControl:o.cacheControl})}let t=q.html;if(!p||P||ar)return(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:t,cacheControl:o.cacheControl});if(au)return t.push(new ReadableStream({start(a){a.enqueue(B.ENCODED_TAGS.CLOSED.BODY_AND_HTML),a.close()}})),(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:t,cacheControl:{revalidate:0,expire:void 0}});let u=new TransformStream;return t.push(u.readable),l({span:c,postponed:q.postponed,fallbackRouteParams:null}).then(async a=>{var b,c;if(!a)throw Object.defineProperty(Error("Invariant: expected a result to be returned"),"__NEXT_ERROR_CODE",{value:"E463",enumerable:!1,configurable:!0});if((null==(b=a.value)?void 0:b.kind)!==x.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant: expected a page response, got ${null==(c=a.value)?void 0:c.kind}`),"__NEXT_ERROR_CODE",{value:"E305",enumerable:!1,configurable:!0});await a.value.html.pipeTo(u.writable)}).catch(a=>{u.writable.abort(a).catch(a=>{console.error("couldn't abort transformer",a)})}),(0,C.sendRenderResult)({req:a,res:b,generateEtags:af.generateEtags,poweredByHeader:af.poweredByHeader,result:t,cacheControl:{revalidate:0,expire:void 0}})};if(!aH)return await aG.withPropagatedContext(a.headers,()=>aG.trace(j.BaseServerSpan.handleRequest,{spanName:`${aF} ${a.url}`,kind:h.SpanKind.SERVER,attributes:{"http.method":aF,"http.target":a.url}},o));await o(aH)}catch(b){throw b instanceof D.NoFallbackError||await M.onRequestError(a,b,{routerKind:"App Router",routePath:I,routeType:"render",revalidateReason:(0,g.c)({isRevalidate:am,isOnDemandRevalidate:aj})},ae),b}}},55241:(a,b,c)=>{"use strict";function d(a){let b=Math.max(0,a);if(b<6e4){let a=Math.ceil(b/100);return`${Math.floor(a/10)}.${a%10}`}let c=Math.ceil(b/1e3),d=Math.floor(c/60);return`${d}:${String(c%60).padStart(2,"0")}`}c.d(b,{ei:()=>d})},55511:a=>{"use strict";a.exports=require("crypto")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66434:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,65169,23)),Promise.resolve().then(c.bind(c,32469))},66570:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>l,dynamic:()=>k});var d=c(75338),e=c(82161),f=c(49224),g=c(32469),h=c(12025),i=c(10326),j=c(2050);let k="force-dynamic";async function l({params:a}){let{id:b}=await a;(0,i.eJ)(b)||(0,e.notFound)();let c=(0,j.O)({gameId:b,organizationId:null});return(0,d.jsxs)("div",{className:"min-h-screen",children:[(0,d.jsx)(f.V,{subtitle:`${c.tournamentName} \xb7 ${c.divisionName}`}),(0,d.jsxs)("main",{className:"mx-auto max-w-3xl px-4 py-8",children:[(0,d.jsxs)("h1",{className:"text-2xl font-black",children:[c.home.name," vs ",c.away.name]}),(0,d.jsxs)("p",{className:"muted mt-1",children:[(0,h.r6)(c.scheduledAt)," \xb7 ",c.venueName??"Venue TBD"]}),(0,d.jsx)("div",{className:"mt-5",children:(0,d.jsx)(g.PublicLive,{gameId:b,initial:c})}),(0,d.jsx)("p",{className:"mt-6 rounded-lg border border-slate-200 bg-white px-4 py-3 text-xs text-slate-600",children:"Scores on this page come from the venue's local scoring system. When the venue has no internet, this page cannot update — the timestamp above shows how fresh the cloud copy is. The official record always lives on the tournament laptop until it is synchronized."})]}),(0,d.jsx)(f.r,{})]})}},67115:(a,b,c)=>{"use strict";c.d(b,{Si:()=>e,Yv:()=>g,kF:()=>f});var d=c(77598);function e(a){return`${a}_${(0,d.randomUUID)().replaceAll("-","")}`}function f(){return new Date().toISOString()}function g(a){return a.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g,"").trim().replace(/[\s_]+/g,"-").replace(/-+/g,"-").slice(0,60)}},73024:a=>{"use strict";a.exports=require("node:fs")},76760:a=>{"use strict";a.exports=require("node:path")},77598:a=>{"use strict";a.exports=require("node:crypto")},79032:(a,b,c)=>{"use strict";c.d(b,{Lf:()=>j,Rn:()=>l});var d=c(79868),e=c(73024),f=c(76760),g=c(26787);function h(){let a=process.env.LOCAL_DB_PATH?.trim()||"./data/local.sqlite";return":memory:"===a?a:(0,f.resolve)(process.cwd(),a)}let i=globalThis;function j(){let a=h();if(i.__semDb?.db&&i.__semDb.path===a)return i.__semDb.db;let b=function(a=h()){":memory:"!==a&&(0,e.mkdirSync)((0,f.dirname)(a),{recursive:!0});let b=new d.DatabaseSync(a);b.exec("PRAGMA journal_mode = WAL"),b.exec("PRAGMA foreign_keys = ON"),b.exec("PRAGMA busy_timeout = 5000"),b.exec("PRAGMA synchronous = FULL");b.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
  )`);let c=new Set(b.prepare("SELECT version FROM schema_migrations").all().map(a=>a.version));for(let a of g.o)if(!c.has(a.version)){b.exec("BEGIN IMMEDIATE");try{b.exec(a.sql),b.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)").run(a.version,new Date().toISOString()),b.exec("COMMIT")}catch(c){throw b.exec("ROLLBACK"),Error(`Migration ${a.version} failed: ${c.message}`,{cause:c})}}return b.prepare("INSERT OR IGNORE INTO sports (key, name, created_at) VALUES (?, ?, ?)").run("basketball","Basketball",new Date().toISOString()),b}(a);return i.__semDb={db:b,path:a},b}let k=0;function l(a){let b=j();if(k>0)return a(b);b.exec("BEGIN IMMEDIATE"),k+=1;try{let c=a(b);return k-=1,b.exec("COMMIT"),c}catch(a){k-=1;try{b.exec("ROLLBACK")}catch{}throw a}}},79868:a=>{"use strict";a.exports=require("node:sqlite")},85710:(a,b,c)=>{"use strict";c.d(b,{Gq:()=>g,Y6:()=>e,mX:()=>f,o0:()=>h,uV:()=>d});class d extends Error{constructor(a,b,c){super(b),this.name="AppError",this.code=a,this.status=function(a){switch(a){case"unauthorized":return 401;case"forbidden":return 403;case"not_found":return 404;case"validation":return 422;case"conflict":return 409;case"rate_limited":return 429;case"unavailable":return 503}}(a),this.details=c}}function e(a){return a instanceof d}function f(a="Record"){return new d("not_found",`${a} not found`)}function g(a,b){return new d("validation",a,b)}function h(a="You do not have permission to do that."){return new d("forbidden",a)}},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[4887,6900,4792,6899,2162,7268,326,1685],()=>b(b.s=54760));module.exports=c})();