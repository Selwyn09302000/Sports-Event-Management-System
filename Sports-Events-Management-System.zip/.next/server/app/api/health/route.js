(()=>{var a={};a.id=2772,a.ids=[2772],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3421:(a,b,c)=>{"use strict";Object.defineProperty(b,"I",{enumerable:!0,get:function(){return g}});let d=c(71237),e=c(55088),f=c(17679);async function g(a,b,c,g){if((0,d.isNodeNextResponse)(b)){var h;b.statusCode=c.status,b.statusMessage=c.statusText;let d=["set-cookie","www-authenticate","proxy-authenticate","vary"];null==(h=c.headers)||h.forEach((a,c)=>{if("x-middleware-set-cookie"!==c.toLowerCase())if("set-cookie"===c.toLowerCase())for(let d of(0,f.splitCookiesString)(a))b.appendHeader(c,d);else{let e=void 0!==b.getHeader(c);(d.includes(c.toLowerCase())||!e)&&b.appendHeader(c,a)}});let{originalResponse:i}=b;c.body&&"HEAD"!==a.method?await (0,e.pipeToNodeResponse)(c.body,i,g):i.end()}}},9827:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>F,patchFetch:()=>E,routeModule:()=>A,serverHooks:()=>D,workAsyncStorage:()=>B,workUnitAsyncStorage:()=>C});var d={};c.r(d),c.d(d,{GET:()=>z,dynamic:()=>y});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(34679),u=c(51356),v=c(12971),w=c(26787),x=c(17591);let y="force-dynamic";async function z(){let a=(0,v.xH)("SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1");return Response.json({ok:!0,mode:"local-first",schemaVersion:a?.version??null,expectedSchemaVersion:w.Z,cloudSyncConfigured:(0,x._)(),serverTime:new Date().toISOString()})}let A=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/health/route",pathname:"/api/health",filename:"route",bundlePath:"app/api/health/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\Users\\ACERNITRO2026\\Desktop\\Sports-Events-Management-System\\src\\app\\api\\health\\route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:B,workUnitAsyncStorage:C,serverHooks:D}=A;function E(){return(0,g.patchFetch)({workAsyncStorage:B,workUnitAsyncStorage:C})}async function F(a,b,c){var d;let e="/api/health/route";"/index"===e&&(e="/");let g=await A.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:v,params:w,nextConfig:x,isDraftMode:y,prerenderManifest:z,routerServerContext:B,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,resolvedPathname:E}=g,F=(0,j.normalizeAppPath)(e),G=!!z.routes[E]&&(A.isDev||(0,t.isRouteCacheOwner)(E,A.cacheOwner,z.routes[E])),H=!!(z.dynamicRoutes[F]||G);if(H&&!y){let a=z.dynamicRoutes[F];if(a&&!1===a.fallback&&!G)throw new s.NoFallbackError}let I=null;!H||A.isDev||y||(I="/index"===(I=E)?"/":I);let J=!0===A.isDev||!H,K=H&&!J,L=a.method||"GET",M=(0,i.getTracer)(),N=M.getActiveScopeSpan(),O={params:w,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!x.experimental.cacheComponents,authInterrupts:!!x.experimental.authInterrupts},supportsDynamicResponse:J,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=x.experimental)?void 0:d.cacheLife,isRevalidate:K,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>A.onRequestError(a,b,d,B)},sharedContext:{buildId:v}},P=new k.NodeNextRequest(a),Q=new k.NodeNextResponse(b),R=l.NextRequestAdapter.fromNodeNextRequest(P,(0,l.signalFromNodeResponse)(b));try{let d=async c=>A.handle(R,O).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=M.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${L} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${L} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&C&&D&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=O.renderOpts.fetchMetrics;let i=O.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=O.renderOpts.collectedTags;if(!H)return await (0,o.I)(P,Q,e,O.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==O.renderOpts.collectedRevalidate&&!(O.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&O.renderOpts.collectedRevalidate,d=void 0===O.renderOpts.collectedExpire||O.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:O.renderOpts.collectedExpire;return{value:{kind:u.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await A.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:C})},B),b}},l=await A.handleResponse({req:a,nextConfig:x,cacheKey:I,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,responseGenerator:k,waitUntil:c.waitUntil});if(!H)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==u.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",C?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&H||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(P,Q,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};N?await g(N):await M.withPropagatedContext(a.headers,()=>M.trace(m.BaseServerSpan.handleRequest,{spanName:`${L} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":L,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await A.onRequestError(a,b,{routerKind:"App Router",routePath:F,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:C})}),H)throw b;return await (0,o.I)(P,Q,new Response(null,{status:500})),null}}},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12971:(a,b,c)=>{"use strict";c.d(b,{Q7:()=>f,eF:()=>h,qF:()=>i,xH:()=>g});var d=c(79032);function e(a){return void 0===a?null:"boolean"==typeof a?+!!a:a}function f(a,b=[],c=(0,d.Lf)()){return c.prepare(a).all(...b.map(e))}function g(a,b=[],c=(0,d.Lf)()){return c.prepare(a).get(...b.map(e))}function h(a,b=[],c=(0,d.Lf)()){return{changes:Number(c.prepare(a).run(...b.map(e)).changes)}}function i(a,b){if(!a)return b;try{return JSON.parse(a)}catch{return b}}},17591:(a,b,c)=>{"use strict";c.d(b,{N:()=>h,_:()=>i});class d{async push(a){return a.map(a=>({operationId:a.operationId,status:"pending",error:"Cloud sync is not configured. Set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY and SYNC_ENABLED=true."}))}constructor(){this.name="disabled",this.enabled=!1}}function e(){let a=process.env.SUPABASE_URL?.trim(),b=process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();return a&&b&&"true"===process.env.SYNC_ENABLED?{url:a.replace(/\/$/,""),serviceRoleKey:b}:null}class f{constructor(a){this.config=a,this.name="supabase",this.enabled=!0}headers(a={}){return{apikey:this.config.serviceRoleKey,Authorization:`Bearer ${this.config.serviceRoleKey}`,"Content-Type":"application/json",...a}}async push(a){let b=[];for(let c of a)b.push(await this.pushOne(c));return b}async pushOne(a){try{switch(a.entityType){case"game_event":return await this.insertEvent(a);case"game_event_void":return await this.voidEvent(a);case"game_result":return await this.insertResult(a);default:return{operationId:a.operationId,status:"rejected",error:`Unsupported sync entity type: ${a.entityType}`}}}catch(b){return{operationId:a.operationId,status:"pending",error:`Network error: ${b.message}`}}}async insertEvent(a){let b=a.payload,c={id:b.eventId,organization_id:b.organizationId,tournament_id:b.tournamentId,game_id:b.gameId,team_id:b.teamId,player_id:b.playerId,event_type:b.eventType,period:b.period,clock_seconds_remaining:b.clockSecondsRemaining,occurred_at:b.occurredAt,recorded_by:b.recordedBy,device_id:b.deviceId,payload:b.payload,schema_version:b.schemaVersion??1,seq:b.seq,sync_status:"synchronized"},d=await fetch(`${this.config.url}/rest/v1/game_events`,{method:"POST",headers:this.headers({Prefer:"resolution=ignore-duplicates,return=minimal"}),body:JSON.stringify(c)});return d.ok?{operationId:a.operationId,status:"synchronized",confirmedAt:new Date().toISOString()}:409===d.status?{operationId:a.operationId,status:"conflicted",error:"Cloud already holds a different record for this event."}:d.status>=500?{operationId:a.operationId,status:"pending",error:`Cloud returned ${d.status}.`}:{operationId:a.operationId,status:"rejected",error:`Cloud rejected the event (${d.status}): ${g(await d.text())}`}}async voidEvent(a){let b=a.payload,c=await fetch(`${this.config.url}/rest/v1/game_events?id=eq.${encodeURIComponent(String(b.eventId))}`,{method:"PATCH",headers:this.headers({Prefer:"return=minimal"}),body:JSON.stringify({voided_at:b.voidedAt,voided_by:b.voidedBy,void_reason:b.reason,sync_status:"synchronized"})});return c.ok?{operationId:a.operationId,status:"synchronized",confirmedAt:new Date().toISOString()}:c.status>=500?{operationId:a.operationId,status:"pending",error:`Cloud returned ${c.status}.`}:{operationId:a.operationId,status:"rejected",error:`Cloud rejected the void (${c.status}): ${g(await c.text())}`}}async insertResult(a){let b=a.payload,c=await fetch(`${this.config.url}/rest/v1/game_results?game_id=eq.${encodeURIComponent(String(b.gameId))}&status=eq.approved&select=home_score,away_score`,{headers:this.headers()});if(c.ok&&(await c.json()).find(a=>a.home_score!==b.homeScore||a.away_score!==b.awayScore))return{operationId:a.operationId,status:"conflicted",error:"The cloud already holds a different approved result for this game. Reconcile before retrying."};let d=await fetch(`${this.config.url}/rest/v1/game_results`,{method:"POST",headers:this.headers({Prefer:"resolution=ignore-duplicates,return=minimal"}),body:JSON.stringify({id:b.resultId,organization_id:b.organizationId,tournament_id:b.tournamentId,game_id:b.gameId,home_score:b.homeScore,away_score:b.awayScore,status:"approved",submitted_by:b.submittedBy,submitted_at:b.submittedAt,approved_by:b.approvedBy,approved_at:b.approvedAt})});return d.ok?{operationId:a.operationId,status:"synchronized",confirmedAt:new Date().toISOString()}:409===d.status?{operationId:a.operationId,status:"conflicted",error:"Duplicate approved result detected."}:{operationId:a.operationId,status:"pending",error:`Cloud returned ${d.status}: ${g(await d.text())}`}}}function g(a,b=300){return a.length>b?`${a.slice(0,b)}…`:a}function h(){let a=e();return a?new f(a):new d}function i(){return null!==e()}},26787:(a,b,c)=>{"use strict";c.d(b,{Z:()=>e,o:()=>d});let d=[{version:"0001_init",sql:`CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  contact_email TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  roles TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TEXT NOT NULL,
  UNIQUE (organization_id, user_id)
);
CREATE INDEX idx_members_user ON organization_members(user_id);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  active_organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE sports (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE tournaments (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  starts_on TEXT,
  ends_on TEXT,
  sport_key TEXT NOT NULL REFERENCES sports(key),
  format TEXT NOT NULL DEFAULT 'round_robin',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  ruleset_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT,
  roster_locked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tournaments_org ON tournaments(organization_id, status);

CREATE TABLE divisions (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age_group TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, name)
);

CREATE TABLE teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  short_name TEXT,
  color TEXT,
  logo_url TEXT,
  contact_name TEXT,
  contact_phone TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_teams_org ON teams(organization_id);

CREATE TABLE tournament_teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  seed INTEGER,
  status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','confirmed','withdrawn')),
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id)
);
CREATE INDEX idx_tournament_teams_div ON tournament_teams(division_id);

CREATE TABLE players (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  birth_date TEXT,
  guardian_name TEXT,
  contact_phone TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_players_org ON players(organization_id);

CREATE TABLE roster_entries (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','inactive')),
  eligible INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id, jersey_number),
  UNIQUE (tournament_id, player_id)
);
CREATE INDEX idx_roster_team ON roster_entries(team_id);

CREATE TABLE venues (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  address TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE games (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  home_team_id TEXT NOT NULL REFERENCES teams(id),
  away_team_id TEXT NOT NULL REFERENCES teams(id),
  venue_id TEXT REFERENCES venues(id) ON DELETE SET NULL,
  scheduled_at TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  stage TEXT NOT NULL DEFAULT 'group',
  round_number INTEGER NOT NULL DEFAULT 1,
  bracket_slot INTEGER,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  current_period INTEGER NOT NULL DEFAULT 1,
  period_count INTEGER NOT NULL DEFAULT 4,
  period_seconds INTEGER NOT NULL DEFAULT 600,
  version INTEGER NOT NULL DEFAULT 1,
  last_event_seq INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (home_team_id <> away_team_id)
);
CREATE INDEX idx_games_tournament ON games(tournament_id, scheduled_at);
CREATE INDEX idx_games_org ON games(organization_id, status);

CREATE TABLE game_periods (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  period_number INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  started_at TEXT,
  ended_at TEXT,
  PRIMARY KEY (game_id, period_number)
);

CREATE TABLE game_clock_states (
  game_id TEXT PRIMARY KEY REFERENCES games(id) ON DELETE CASCADE,
  period INTEGER NOT NULL,
  remaining_ms INTEGER NOT NULL,
  running INTEGER NOT NULL DEFAULT 0,
  anchor_at TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

CREATE TABLE game_events (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  team_id TEXT,
  player_id TEXT,
  event_type TEXT NOT NULL,
  period INTEGER NOT NULL,
  clock_seconds_remaining INTEGER NOT NULL DEFAULT 0,
  occurred_at TEXT NOT NULL,
  recorded_by TEXT NOT NULL,
  recorded_by_name TEXT,
  device_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  schema_version INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  client_action_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synchronized','conflicted','rejected','local_only')),
  voided_at TEXT,
  voided_by TEXT,
  void_reason TEXT,
  corrects_event_id TEXT,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX idx_game_events_client_action ON game_events(game_id, client_action_id) WHERE client_action_id IS NOT NULL;
CREATE INDEX idx_game_events_game_seq ON game_events(game_id, seq);
CREATE INDEX idx_game_events_sync ON game_events(organization_id, sync_status);

CREATE TABLE player_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fgm2 INTEGER NOT NULL DEFAULT 0,
  fga2 INTEGER NOT NULL DEFAULT 0,
  fgm3 INTEGER NOT NULL DEFAULT 0,
  fga3 INTEGER NOT NULL DEFAULT 0,
  ftm INTEGER NOT NULL DEFAULT 0,
  fta INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  offensive_rebounds INTEGER NOT NULL DEFAULT 0,
  defensive_rebounds INTEGER NOT NULL DEFAULT 0,
  assists INTEGER NOT NULL DEFAULT 0,
  steals INTEGER NOT NULL DEFAULT 0,
  blocks INTEGER NOT NULL DEFAULT 0,
  turnovers INTEGER NOT NULL DEFAULT 0,
  substitutions INTEGER NOT NULL DEFAULT 0,
  seconds_played INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, player_id)
);

CREATE TABLE team_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  timeouts_used INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, team_id)
);

CREATE TABLE game_results (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  home_score INTEGER NOT NULL,
  away_score INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('submitted','approved','rejected','superseded')),
  submitted_by TEXT NOT NULL,
  submitted_at TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  rejection_reason TEXT,
  corrected_from_id TEXT,
  final_event_seq INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_results_game ON game_results(game_id, created_at);

CREATE TABLE tournament_rounds (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number)
);

CREATE TABLE bracket_advancements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  source_game_id TEXT,
  winner_team_id TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number, slot)
);

CREATE TABLE announcements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT REFERENCES tournaments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  published_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  device_key TEXT NOT NULL UNIQUE,
  authorized INTEGER NOT NULL DEFAULT 1,
  last_seen_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE sync_operations (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation TEXT NOT NULL DEFAULT 'upsert',
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','pushed','synchronized','conflicted','rejected')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  remote_confirmed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_sync_status ON sync_operations(status, created_at);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_user_id TEXT,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_org ON audit_logs(organization_id, created_at);
`}],e=d[d.length-1].version},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{"use strict";a.exports=require("crypto")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:a=>{"use strict";a.exports=require("node:fs")},76760:a=>{"use strict";a.exports=require("node:path")},78335:()=>{},79032:(a,b,c)=>{"use strict";c.d(b,{Lf:()=>j,Rn:()=>l});var d=c(79868),e=c(73024),f=c(76760),g=c(26787);function h(){let a=process.env.LOCAL_DB_PATH?.trim()||"./data/local.sqlite";return":memory:"===a?a:(0,f.resolve)(process.cwd(),a)}let i=globalThis;function j(){let a=h();if(i.__semDb?.db&&i.__semDb.path===a)return i.__semDb.db;let b=function(a=h()){":memory:"!==a&&(0,e.mkdirSync)((0,f.dirname)(a),{recursive:!0});let b=new d.DatabaseSync(a);b.exec("PRAGMA journal_mode = WAL"),b.exec("PRAGMA foreign_keys = ON"),b.exec("PRAGMA busy_timeout = 5000"),b.exec("PRAGMA synchronous = FULL");b.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
  )`);let c=new Set(b.prepare("SELECT version FROM schema_migrations").all().map(a=>a.version));for(let a of g.o)if(!c.has(a.version)){b.exec("BEGIN IMMEDIATE");try{b.exec(a.sql),b.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)").run(a.version,new Date().toISOString()),b.exec("COMMIT")}catch(c){throw b.exec("ROLLBACK"),Error(`Migration ${a.version} failed: ${c.message}`,{cause:c})}}return b.prepare("INSERT OR IGNORE INTO sports (key, name, created_at) VALUES (?, ?, ?)").run("basketball","Basketball",new Date().toISOString()),b}(a);return i.__semDb={db:b,path:a},b}let k=0;function l(a){let b=j();if(k>0)return a(b);b.exec("BEGIN IMMEDIATE"),k+=1;try{let c=a(b);return k-=1,b.exec("COMMIT"),c}catch(a){k-=1;try{b.exec("ROLLBACK")}catch{}throw a}}},79868:a=>{"use strict";a.exports=require("node:sqlite")},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},95736:(a,b,c)=>{"use strict";a.exports=c(44870)},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[4887],()=>b(b.s=9827));module.exports=c})();