"use strict";exports.id=3899,exports.ids=[3899],exports.modules={12971:(a,b,c)=>{c.d(b,{Q7:()=>f,eF:()=>h,qF:()=>i,xH:()=>g});var d=c(79032);function e(a){return void 0===a?null:"boolean"==typeof a?+!!a:a}function f(a,b=[],c=(0,d.Lf)()){return c.prepare(a).all(...b.map(e))}function g(a,b=[],c=(0,d.Lf)()){return c.prepare(a).get(...b.map(e))}function h(a,b=[],c=(0,d.Lf)()){return{changes:Number(c.prepare(a).run(...b.map(e)).changes)}}function i(a,b){if(!a)return b;try{return JSON.parse(a)}catch{return b}}},19927:(a,b,c)=>{c.d(b,{PS:()=>k,_m:()=>j,fn:()=>f,qn:()=>m,zH:()=>l});var d=c(85710);let e=["platform_admin","org_admin","tournament_manager","registrar","scorer","statistician","official","team_manager","viewer"],f={platform_admin:"Platform Super Admin",org_admin:"Organization Administrator",tournament_manager:"Tournament Manager",registrar:"Registrar",scorer:"Scorer",statistician:"Statistics Recorder",official:"Approving Official",team_manager:"Team Manager",viewer:"Viewer"},g=["org.manage","member.manage","tournament.manage","roster.manage","game.score","stats.record","game.review","result.approve","sync.manage","audit.read","device.manage"],h=[...g],i={platform_admin:[...g],org_admin:h,tournament_manager:["tournament.manage","roster.manage","game.score","stats.record","audit.read"],registrar:["roster.manage"],scorer:["game.score","stats.record"],statistician:["stats.record"],official:["game.review","result.approve","audit.read"],team_manager:["roster.manage"],viewer:[]};function j(a,b){return(function(a){let b=new Set;for(let c of a)for(let a of i[c]??[])b.add(a);return b})(a).has(b)}function k(a,b){if(!j(a,b))throw(0,d.o0)(`Your role does not allow "${b}".`)}function l(a){if(!Array.isArray(a))return[];let b=new Set(e);return[...new Set(a.filter(a=>"string"==typeof a&&b.has(a)))]}let m=e.filter(a=>"platform_admin"!==a)},26787:(a,b,c)=>{c.d(b,{Z:()=>e,o:()=>d});let d=[{version:"0001_init",sql:`CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  contact_email TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  roles TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TEXT NOT NULL,
  UNIQUE (organization_id, user_id)
);
CREATE INDEX idx_members_user ON organization_members(user_id);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  active_organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE sports (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE tournaments (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  starts_on TEXT,
  ends_on TEXT,
  sport_key TEXT NOT NULL REFERENCES sports(key),
  format TEXT NOT NULL DEFAULT 'round_robin',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  ruleset_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT,
  roster_locked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tournaments_org ON tournaments(organization_id, status);

CREATE TABLE divisions (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age_group TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, name)
);

CREATE TABLE teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  short_name TEXT,
  color TEXT,
  logo_url TEXT,
  contact_name TEXT,
  contact_phone TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_teams_org ON teams(organization_id);

CREATE TABLE tournament_teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  seed INTEGER,
  status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','confirmed','withdrawn')),
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id)
);
CREATE INDEX idx_tournament_teams_div ON tournament_teams(division_id);

CREATE TABLE players (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  birth_date TEXT,
  guardian_name TEXT,
  contact_phone TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_players_org ON players(organization_id);

CREATE TABLE roster_entries (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','inactive')),
  eligible INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id, jersey_number),
  UNIQUE (tournament_id, player_id)
);
CREATE INDEX idx_roster_team ON roster_entries(team_id);

CREATE TABLE venues (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  address TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE games (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  home_team_id TEXT NOT NULL REFERENCES teams(id),
  away_team_id TEXT NOT NULL REFERENCES teams(id),
  venue_id TEXT REFERENCES venues(id) ON DELETE SET NULL,
  scheduled_at TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  stage TEXT NOT NULL DEFAULT 'group',
  round_number INTEGER NOT NULL DEFAULT 1,
  bracket_slot INTEGER,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  current_period INTEGER NOT NULL DEFAULT 1,
  period_count INTEGER NOT NULL DEFAULT 4,
  period_seconds INTEGER NOT NULL DEFAULT 600,
  version INTEGER NOT NULL DEFAULT 1,
  last_event_seq INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (home_team_id <> away_team_id)
);
CREATE INDEX idx_games_tournament ON games(tournament_id, scheduled_at);
CREATE INDEX idx_games_org ON games(organization_id, status);

CREATE TABLE game_periods (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  period_number INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  started_at TEXT,
  ended_at TEXT,
  PRIMARY KEY (game_id, period_number)
);

CREATE TABLE game_clock_states (
  game_id TEXT PRIMARY KEY REFERENCES games(id) ON DELETE CASCADE,
  period INTEGER NOT NULL,
  remaining_ms INTEGER NOT NULL,
  running INTEGER NOT NULL DEFAULT 0,
  anchor_at TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

CREATE TABLE game_events (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  team_id TEXT,
  player_id TEXT,
  event_type TEXT NOT NULL,
  period INTEGER NOT NULL,
  clock_seconds_remaining INTEGER NOT NULL DEFAULT 0,
  occurred_at TEXT NOT NULL,
  recorded_by TEXT NOT NULL,
  recorded_by_name TEXT,
  device_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  schema_version INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  client_action_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synchronized','conflicted','rejected','local_only')),
  voided_at TEXT,
  voided_by TEXT,
  void_reason TEXT,
  corrects_event_id TEXT,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX idx_game_events_client_action ON game_events(game_id, client_action_id) WHERE client_action_id IS NOT NULL;
CREATE INDEX idx_game_events_game_seq ON game_events(game_id, seq);
CREATE INDEX idx_game_events_sync ON game_events(organization_id, sync_status);

CREATE TABLE player_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fgm2 INTEGER NOT NULL DEFAULT 0,
  fga2 INTEGER NOT NULL DEFAULT 0,
  fgm3 INTEGER NOT NULL DEFAULT 0,
  fga3 INTEGER NOT NULL DEFAULT 0,
  ftm INTEGER NOT NULL DEFAULT 0,
  fta INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  offensive_rebounds INTEGER NOT NULL DEFAULT 0,
  defensive_rebounds INTEGER NOT NULL DEFAULT 0,
  assists INTEGER NOT NULL DEFAULT 0,
  steals INTEGER NOT NULL DEFAULT 0,
  blocks INTEGER NOT NULL DEFAULT 0,
  turnovers INTEGER NOT NULL DEFAULT 0,
  substitutions INTEGER NOT NULL DEFAULT 0,
  seconds_played INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, player_id)
);

CREATE TABLE team_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  timeouts_used INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, team_id)
);

CREATE TABLE game_results (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  home_score INTEGER NOT NULL,
  away_score INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('submitted','approved','rejected','superseded')),
  submitted_by TEXT NOT NULL,
  submitted_at TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  rejection_reason TEXT,
  corrected_from_id TEXT,
  final_event_seq INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_results_game ON game_results(game_id, created_at);

CREATE TABLE tournament_rounds (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number)
);

CREATE TABLE bracket_advancements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  source_game_id TEXT,
  winner_team_id TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number, slot)
);

CREATE TABLE announcements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT REFERENCES tournaments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  published_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  device_key TEXT NOT NULL UNIQUE,
  authorized INTEGER NOT NULL DEFAULT 1,
  last_seen_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE sync_operations (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation TEXT NOT NULL DEFAULT 'upsert',
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','pushed','synchronized','conflicted','rejected')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  remote_confirmed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_sync_status ON sync_operations(status, created_at);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_user_id TEXT,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_org ON audit_logs(organization_id, created_at);
`}],e=d[d.length-1].version},67115:(a,b,c)=>{c.d(b,{Si:()=>e,Yv:()=>g,kF:()=>f});var d=c(77598);function e(a){return`${a}_${(0,d.randomUUID)().replaceAll("-","")}`}function f(){return new Date().toISOString()}function g(a){return a.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g,"").trim().replace(/[\s_]+/g,"-").replace(/-+/g,"-").slice(0,60)}},79032:(a,b,c)=>{c.d(b,{Lf:()=>j,Rn:()=>l});var d=c(79868),e=c(73024),f=c(76760),g=c(26787);function h(){let a=process.env.LOCAL_DB_PATH?.trim()||"./data/local.sqlite";return":memory:"===a?a:(0,f.resolve)(process.cwd(),a)}let i=globalThis;function j(){let a=h();if(i.__semDb?.db&&i.__semDb.path===a)return i.__semDb.db;let b=function(a=h()){":memory:"!==a&&(0,e.mkdirSync)((0,f.dirname)(a),{recursive:!0});let b=new d.DatabaseSync(a);b.exec("PRAGMA journal_mode = WAL"),b.exec("PRAGMA foreign_keys = ON"),b.exec("PRAGMA busy_timeout = 5000"),b.exec("PRAGMA synchronous = FULL");b.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
  )`);let c=new Set(b.prepare("SELECT version FROM schema_migrations").all().map(a=>a.version));for(let a of g.o)if(!c.has(a.version)){b.exec("BEGIN IMMEDIATE");try{b.exec(a.sql),b.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)").run(a.version,new Date().toISOString()),b.exec("COMMIT")}catch(c){throw b.exec("ROLLBACK"),Error(`Migration ${a.version} failed: ${c.message}`,{cause:c})}}return b.prepare("INSERT OR IGNORE INTO sports (key, name, created_at) VALUES (?, ?, ?)").run("basketball","Basketball",new Date().toISOString()),b}(a);return i.__semDb={db:b,path:a},b}let k=0;function l(a){let b=j();if(k>0)return a(b);b.exec("BEGIN IMMEDIATE"),k+=1;try{let c=a(b);return k-=1,b.exec("COMMIT"),c}catch(a){k-=1;try{b.exec("ROLLBACK")}catch{}throw a}}},85710:(a,b,c)=>{c.d(b,{Gq:()=>g,Y6:()=>e,mX:()=>f,o0:()=>h,uV:()=>d});class d extends Error{constructor(a,b,c){super(b),this.name="AppError",this.code=a,this.status=function(a){switch(a){case"unauthorized":return 401;case"forbidden":return 403;case"not_found":return 404;case"validation":return 422;case"conflict":return 409;case"rate_limited":return 429;case"unavailable":return 503}}(a),this.details=c}}function e(a){return a instanceof d}function f(a="Record"){return new d("not_found",`${a} not found`)}function g(a,b){return new d("validation",a,b)}function h(a="You do not have permission to do that."){return new d("forbidden",a)}}};