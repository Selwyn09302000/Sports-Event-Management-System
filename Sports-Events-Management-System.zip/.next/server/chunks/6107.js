exports.id=6107,exports.ids=[6107],exports.modules={10615:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,65169,23))},12971:(a,b,c)=>{"use strict";c.d(b,{Q7:()=>f,eF:()=>h,qF:()=>i,xH:()=>g});var d=c(79032);function e(a){return void 0===a?null:"boolean"==typeof a?+!!a:a}function f(a,b=[],c=(0,d.Lf)()){return c.prepare(a).all(...b.map(e))}function g(a,b=[],c=(0,d.Lf)()){return c.prepare(a).get(...b.map(e))}function h(a,b=[],c=(0,d.Lf)()){return{changes:Number(c.prepare(a).run(...b.map(e)).changes)}}function i(a,b){if(!a)return b;try{return JSON.parse(a)}catch{return b}}},26787:(a,b,c)=>{"use strict";c.d(b,{Z:()=>e,o:()=>d});let d=[{version:"0001_init",sql:`CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  contact_email TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  roles TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TEXT NOT NULL,
  UNIQUE (organization_id, user_id)
);
CREATE INDEX idx_members_user ON organization_members(user_id);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  active_organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE sports (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE tournaments (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  starts_on TEXT,
  ends_on TEXT,
  sport_key TEXT NOT NULL REFERENCES sports(key),
  format TEXT NOT NULL DEFAULT 'round_robin',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  ruleset_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT,
  roster_locked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tournaments_org ON tournaments(organization_id, status);

CREATE TABLE divisions (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age_group TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, name)
);

CREATE TABLE teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  short_name TEXT,
  color TEXT,
  logo_url TEXT,
  contact_name TEXT,
  contact_phone TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_teams_org ON teams(organization_id);

CREATE TABLE tournament_teams (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  seed INTEGER,
  status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','confirmed','withdrawn')),
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id)
);
CREATE INDEX idx_tournament_teams_div ON tournament_teams(division_id);

CREATE TABLE players (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  birth_date TEXT,
  guardian_name TEXT,
  contact_phone TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_players_org ON players(organization_id);

CREATE TABLE roster_entries (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','inactive')),
  eligible INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE (tournament_id, team_id, jersey_number),
  UNIQUE (tournament_id, player_id)
);
CREATE INDEX idx_roster_team ON roster_entries(team_id);

CREATE TABLE venues (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  address TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE games (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  home_team_id TEXT NOT NULL REFERENCES teams(id),
  away_team_id TEXT NOT NULL REFERENCES teams(id),
  venue_id TEXT REFERENCES venues(id) ON DELETE SET NULL,
  scheduled_at TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  stage TEXT NOT NULL DEFAULT 'group',
  round_number INTEGER NOT NULL DEFAULT 1,
  bracket_slot INTEGER,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  current_period INTEGER NOT NULL DEFAULT 1,
  period_count INTEGER NOT NULL DEFAULT 4,
  period_seconds INTEGER NOT NULL DEFAULT 600,
  version INTEGER NOT NULL DEFAULT 1,
  last_event_seq INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (home_team_id <> away_team_id)
);
CREATE INDEX idx_games_tournament ON games(tournament_id, scheduled_at);
CREATE INDEX idx_games_org ON games(organization_id, status);

CREATE TABLE game_periods (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  period_number INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  started_at TEXT,
  ended_at TEXT,
  PRIMARY KEY (game_id, period_number)
);

CREATE TABLE game_clock_states (
  game_id TEXT PRIMARY KEY REFERENCES games(id) ON DELETE CASCADE,
  period INTEGER NOT NULL,
  remaining_ms INTEGER NOT NULL,
  running INTEGER NOT NULL DEFAULT 0,
  anchor_at TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

CREATE TABLE game_events (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  team_id TEXT,
  player_id TEXT,
  event_type TEXT NOT NULL,
  period INTEGER NOT NULL,
  clock_seconds_remaining INTEGER NOT NULL DEFAULT 0,
  occurred_at TEXT NOT NULL,
  recorded_by TEXT NOT NULL,
  recorded_by_name TEXT,
  device_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  schema_version INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  client_action_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synchronized','conflicted','rejected','local_only')),
  voided_at TEXT,
  voided_by TEXT,
  void_reason TEXT,
  corrects_event_id TEXT,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX idx_game_events_client_action ON game_events(game_id, client_action_id) WHERE client_action_id IS NOT NULL;
CREATE INDEX idx_game_events_game_seq ON game_events(game_id, seq);
CREATE INDEX idx_game_events_sync ON game_events(organization_id, sync_status);

CREATE TABLE player_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fgm2 INTEGER NOT NULL DEFAULT 0,
  fga2 INTEGER NOT NULL DEFAULT 0,
  fgm3 INTEGER NOT NULL DEFAULT 0,
  fga3 INTEGER NOT NULL DEFAULT 0,
  ftm INTEGER NOT NULL DEFAULT 0,
  fta INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  offensive_rebounds INTEGER NOT NULL DEFAULT 0,
  defensive_rebounds INTEGER NOT NULL DEFAULT 0,
  assists INTEGER NOT NULL DEFAULT 0,
  steals INTEGER NOT NULL DEFAULT 0,
  blocks INTEGER NOT NULL DEFAULT 0,
  turnovers INTEGER NOT NULL DEFAULT 0,
  substitutions INTEGER NOT NULL DEFAULT 0,
  seconds_played INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, player_id)
);

CREATE TABLE team_game_statistics (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL,
  team_id TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  fouls INTEGER NOT NULL DEFAULT 0,
  timeouts_used INTEGER NOT NULL DEFAULT 0,
  snapshot_at TEXT NOT NULL,
  PRIMARY KEY (game_id, team_id)
);

CREATE TABLE game_results (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT NOT NULL,
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  home_score INTEGER NOT NULL,
  away_score INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('submitted','approved','rejected','superseded')),
  submitted_by TEXT NOT NULL,
  submitted_at TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  rejection_reason TEXT,
  corrected_from_id TEXT,
  final_event_seq INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_results_game ON game_results(game_id, created_at);

CREATE TABLE tournament_rounds (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number)
);

CREATE TABLE bracket_advancements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  division_id TEXT NOT NULL,
  round_number INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  source_game_id TEXT,
  winner_team_id TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (division_id, round_number, slot)
);

CREATE TABLE announcements (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tournament_id TEXT REFERENCES tournaments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  published_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  device_key TEXT NOT NULL UNIQUE,
  authorized INTEGER NOT NULL DEFAULT 1,
  last_seen_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE sync_operations (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation TEXT NOT NULL DEFAULT 'upsert',
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','pushed','synchronized','conflicted','rejected')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  remote_confirmed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_sync_status ON sync_operations(status, created_at);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_user_id TEXT,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_org ON audit_logs(organization_id, created_at);
`}],e=d[d.length-1].version},63759:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,3991,23))},67115:(a,b,c)=>{"use strict";c.d(b,{Si:()=>e,Yv:()=>g,kF:()=>f});var d=c(77598);function e(a){return`${a}_${(0,d.randomUUID)().replaceAll("-","")}`}function f(){return new Date().toISOString()}function g(a){return a.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g,"").trim().replace(/[\s_]+/g,"-").replace(/-+/g,"-").slice(0,60)}},74390:(a,b,c)=>{"use strict";c.d(b,{UL:()=>h,R:()=>g});var d=c(47023),e=c(12971),f=c(57268);function g(a,b){let c=(0,e.xH)("SELECT id, name, tournament_id FROM divisions WHERE id = ? AND organization_id = ?",[b,a]);if(!c)throw Error("Division not found");let f=(0,e.xH)("SELECT ruleset_json FROM tournaments WHERE id = ?",[c.tournament_id]),g=(0,d.oH)(f?.ruleset_json),h=(0,e.Q7)(`SELECT tt.team_id, t.name, t.short_name
       FROM tournament_teams tt JOIN teams t ON t.id = tt.team_id
      WHERE tt.division_id = ? AND tt.organization_id = ? AND tt.status <> 'withdrawn'
      ORDER BY t.name`,[b,a]),i=(0,e.Q7)(`SELECT r.game_id, g.home_team_id, g.away_team_id, r.home_score, r.away_score
       FROM game_results r JOIN games g ON g.id = r.game_id
      WHERE g.division_id = ? AND g.organization_id = ? AND r.status = 'approved'`,[b,a]),j=function(a,b,c=d.Pm){let e=new Map;for(let b of a)e.set(b,{teamId:b,played:0,wins:0,losses:0,draws:0,pointsFor:0,pointsAgainst:0,pointDiff:0,leaguePoints:0,winPct:0,rank:0});for(let a of b){let b=e.get(a.homeTeamId),d=e.get(a.awayTeamId);b&&d&&(b.played+=1,d.played+=1,b.pointsFor+=a.homeScore,b.pointsAgainst+=a.awayScore,d.pointsFor+=a.awayScore,d.pointsAgainst+=a.homeScore,a.homeScore===a.awayScore?(b.draws+=1,d.draws+=1,b.leaguePoints+=c.standingPoints.loss,d.leaguePoints+=c.standingPoints.loss):a.homeScore>a.awayScore?(b.wins+=1,d.losses+=1,b.leaguePoints+=c.standingPoints.win,d.leaguePoints+=c.standingPoints.loss):(d.wins+=1,b.losses+=1,d.leaguePoints+=c.standingPoints.win,b.leaguePoints+=c.standingPoints.loss))}for(let a of e.values())a.pointDiff=a.pointsFor-a.pointsAgainst,a.winPct=0===a.played?0:a.wins/a.played;return[...e.values()].sort((a,b)=>b.winPct!==a.winPct?b.winPct-a.winPct:b.leaguePoints!==a.leaguePoints?b.leaguePoints-a.leaguePoints:b.pointDiff!==a.pointDiff?b.pointDiff-a.pointDiff:b.pointsFor!==a.pointsFor?b.pointsFor-a.pointsFor:a.teamId.localeCompare(b.teamId)).map((a,b)=>({...a,rank:b+1}))}(h.map(a=>a.team_id),i.map(a=>({gameId:a.game_id,homeTeamId:a.home_team_id,awayTeamId:a.away_team_id,homeScore:a.home_score,awayScore:a.away_score})),g),k=new Map(h.map(a=>[a.team_id,a]));return{divisionId:b,divisionName:c.name,rows:j.map(a=>({...a,teamName:k.get(a.teamId)?.name??a.teamId,teamShort:k.get(a.teamId)?.short_name??null}))}}function h(a,b){let c=(0,e.xH)("SELECT id, name FROM divisions WHERE id = ? AND organization_id = ?",[b,a]);if(!c)throw Error("Division not found");let d=(0,e.Q7)(`${f.$h} WHERE g.organization_id = ? AND g.division_id = ? AND g.stage <> 'group'
      ORDER BY g.round_number, g.bracket_slot`,[a,b]).map(f.dA),g=(0,e.Q7)(`SELECT a.round_number, a.slot, a.winner_team_id, t.name AS team_name
       FROM bracket_advancements a LEFT JOIN teams t ON t.id = a.winner_team_id
      WHERE a.division_id = ? AND a.organization_id = ?`,[b,a]),h=(0,e.Q7)("SELECT round_number, name FROM tournament_rounds WHERE division_id = ? AND organization_id = ? ORDER BY round_number",[b,a]),i=Math.max(0,...h.map(a=>a.round_number),...d.map(a=>a.roundNumber)),j=[];for(let a=1;a<=i;a+=1){let b=d.filter(b=>b.roundNumber===a),c=[];for(let d of b){let b=g.find(b=>b.round_number===a&&b.slot===d.bracketSlot);c.push({round:a,slot:d.bracketSlot??0,game:d,homeTeamId:d.homeTeamId,awayTeamId:d.awayTeamId,homeName:d.homeTeamName,awayName:d.awayTeamName,winnerTeamId:b?.winner_team_id??null,status:d.status})}for(let b of g.filter(b=>b.round_number===a))c.some(a=>a.slot===b.slot)||c.push({round:a,slot:b.slot,game:null,homeTeamId:b.winner_team_id,awayTeamId:null,homeName:b.team_name,awayName:null,winnerTeamId:b.winner_team_id,status:"bye"});c.sort((a,b)=>a.slot-b.slot),j.push({round:a,name:h.find(b=>b.round_number===a)?.name??`Round ${a}`,slots:c})}return{divisionId:b,divisionName:c.name,rounds:j}}},79032:(a,b,c)=>{"use strict";c.d(b,{Lf:()=>j,Rn:()=>l});var d=c(79868),e=c(73024),f=c(76760),g=c(26787);function h(){let a=process.env.LOCAL_DB_PATH?.trim()||"./data/local.sqlite";return":memory:"===a?a:(0,f.resolve)(process.cwd(),a)}let i=globalThis;function j(){let a=h();if(i.__semDb?.db&&i.__semDb.path===a)return i.__semDb.db;let b=function(a=h()){":memory:"!==a&&(0,e.mkdirSync)((0,f.dirname)(a),{recursive:!0});let b=new d.DatabaseSync(a);b.exec("PRAGMA journal_mode = WAL"),b.exec("PRAGMA foreign_keys = ON"),b.exec("PRAGMA busy_timeout = 5000"),b.exec("PRAGMA synchronous = FULL");b.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
  )`);let c=new Set(b.prepare("SELECT version FROM schema_migrations").all().map(a=>a.version));for(let a of g.o)if(!c.has(a.version)){b.exec("BEGIN IMMEDIATE");try{b.exec(a.sql),b.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)").run(a.version,new Date().toISOString()),b.exec("COMMIT")}catch(c){throw b.exec("ROLLBACK"),Error(`Migration ${a.version} failed: ${c.message}`,{cause:c})}}return b.prepare("INSERT OR IGNORE INTO sports (key, name, created_at) VALUES (?, ?, ?)").run("basketball","Basketball",new Date().toISOString()),b}(a);return i.__semDb={db:b,path:a},b}let k=0;function l(a){let b=j();if(k>0)return a(b);b.exec("BEGIN IMMEDIATE"),k+=1;try{let c=a(b);return k-=1,b.exec("COMMIT"),c}catch(a){k-=1;try{b.exec("ROLLBACK")}catch{}throw a}}},85710:(a,b,c)=>{"use strict";c.d(b,{Gq:()=>g,Y6:()=>e,mX:()=>f,o0:()=>h,uV:()=>d});class d extends Error{constructor(a,b,c){super(b),this.name="AppError",this.code=a,this.status=function(a){switch(a){case"unauthorized":return 401;case"forbidden":return 403;case"not_found":return 404;case"validation":return 422;case"conflict":return 409;case"rate_limited":return 429;case"unavailable":return 503}}(a),this.details=c}}function e(a){return a instanceof d}function f(a="Record"){return new d("not_found",`${a} not found`)}function g(a,b){return new d("validation",a,b)}function h(a="You do not have permission to do that."){return new d("forbidden",a)}}};